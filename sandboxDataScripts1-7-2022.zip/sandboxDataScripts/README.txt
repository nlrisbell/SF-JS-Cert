Reference the Client Connect Confluence 'Scripted Sandbox Configuration' for usage.
https://confluence.dhigroupinc.com/display/CC/Scripted+Sandbox+Configuration