#!/bin/bash -e
# Sandbox configuration script for Developer Sandboxes
# This script is run after the second Prodly deployment and CPQ configuration
# Script takes command line parameters separated by a space - the org aliases to update

if [ "$#" -eq 0 ]; then
    echo "You must enter at least one org alias - or several separated by a space"
    exit 1
fi
echo "Start 4-devsandboxconfig"
echo "Orgs to be updated: $@"

for var in "$@"
do
    ORGALIAS="$var"
    echo "Updating org: $ORGALIAS"

    XMLFILE=../../data/force-app/main/default/labels/DQT/DQTCustomLabels.labels-meta.xml
    echo "Working file : $XMLFILE"

    DEPLOYXMLFILE=../../data/force-app/main/default/labels/DQT/CustomLabels.labels-meta.xml
    echo "Deploy file: $DEPLOYXMLFILE"

    TEMPLATEXMLFILE=../../data/force-app/main/default/labels/DQT/DQTCustomLabels.labels-meta-copy.xml
    echo "Template file: $TEMPLATEXMLFILE"

  cp "$TEMPLATEXMLFILE" "$XMLFILE" 

    ### 7 - MODIFY DQT CUSTOM LABEL IDs
    # TODO: loop these with an array of Names - could just use Name as the placeholder in the working file too :-)
    dqtId=`sfdx force:data:soql:query -q "SELECT Id FROM SBQQ__QuoteTemplate__c WHERE Name = 'ClearanceJobs Standard'" -r human -u $ORGALIAS | tail -n -2` 
    theId=${dqtId:0:18}
    echo "The Id: $theId"
    sed -i '' "s/quotetemplatecj/"$theId"/g" $XMLFILE

    dqtId=`sfdx force:data:soql:query -q "SELECT Id FROM SBQQ__QuoteTemplate__c WHERE Name = 'Dice Standard'" -r human -u $ORGALIAS | tail -n -2` 
    theId=${dqtId:0:18}
    echo "The Id: $theId"
    sed -i '' "s/quotetemplatedice/"$theId"/g" $XMLFILE

    dqtId=`sfdx force:data:soql:query -q "SELECT Id FROM SBQQ__QuoteTemplate__c WHERE Name = 'eFC Standard - English'" -r human -u $ORGALIAS | tail -n -2` 
    theId=${dqtId:0:18}
    echo "The Id: $theId"
    sed -i '' "s/quotetemplateefcenglish/"$theId"/g" $XMLFILE

    dqtId=`sfdx force:data:soql:query -q "SELECT Id FROM SBQQ__QuoteTemplate__c WHERE Name = 'eFC Standard - French'" -r human -u $ORGALIAS | tail -n -2` 
    theId=${dqtId:0:18}
    echo "The Id: $theId"
    sed -i '' "s/quotetemplateefcfrench/"$theId"/g" $XMLFILE

    dqtId=`sfdx force:data:soql:query -q "SELECT Id FROM SBQQ__QuoteTemplate__c WHERE Name = 'eFC Standard - German'" -r human -u $ORGALIAS | tail -n -2` 
    theId=${dqtId:0:18}
    echo "The Id: $theId"
    sed -i '' "s/quotetemplateefcgerman/"$theId"/g" $XMLFILE

    dqtId=`sfdx force:data:soql:query -q "SELECT Id FROM SBQQ__QuoteTemplate__c WHERE Name = 'eFC Standard - Italian'" -r human -u $ORGALIAS | tail -n -2` 
    theId=${dqtId:0:18}
    echo "The Id: $theId"
    sed -i '' "s/quotetemplateefcitalian/"$theId"/g" $XMLFILE

    # create CustomLabels.labels-meta.xml
    cp "$XMLFILE" "$DEPLOYXMLFILE"

    # sfdx deploy xml
    sfdx force:source:deploy -p "$DEPLOYXMLFILE" -u $ORGALIAS


done
echo "Finished 4-devsandboxconfig"
