#!/bin/bash
# Sandbox configuration script for Developer Sandboxes
# This script is run after Cloning or Refreshing a sandbox and before the first Prodly deployment to that sandbox
# Script takes one command line parameter - the org alias to update

if [ $# -eq 0 ]; then
    echo "You must enter an org alias"
    exit 1
fi
ORGALIAS=$1
echo "Org to be updated: $ORGALIAS"

echo "BEGINNING 1-devsandboxconfig UpdateProfiles, CustomLabel deploy, UpdateCustomSettings "

### 1 - UPDATE USER PROFILES 
sfdx force:apex:execute -f ../apex/UpdateProfiles.cls

### 2 - DEPLOY CUSTOM LABELS
# currently data only contains CustomLabels.labels-meta.xml
sfdx force:source:deploy -p ../../data/force-app/main/default/labels -u $ORGALIAS

### 3 - UPDATE CUSTOM SETTINGS
cd scripts/apex
pwd
sfdx force:apex:execute -f ../apex/UpdateCustomSettings.cls

### 4 - UPDATE METADATA TYPES
# After refreshing or cloning a new sandbox from Production these MetadataTypes are correct
# - that is the ProfileId, PermissionSetId, and Email Template Ids are valid.
# There is an Apex script included in this zip to perform updates if we need to later 
# but currently we cannot update MDT in Apex - we need to use MDAPI. 

### 6 - Deactivate Account Validation Rule: Initial_AB_Required_for_insert
# Before Prodly deployment - then need to manually reactivate after
sfdx force:source:deploy -p ../../data/force-app/main/default/objects/Account/validationRules -u $ORGALIAS

### 5 - Package Install Provenworks AddressTools v 6.62
sfdx force:package:install --package 04tA0000000834C -u $ORGALIAS

echo "ENDED 1-devsandboxconfig UpdateProfiles, CustomLabel deploy, UpdateCustomSettings"

