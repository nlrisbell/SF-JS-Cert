#!/bin/bash
# Sandbox configuration script for Developer Sandboxes
# This script is run after the first Prodly deployment to the sandbox
# Script takes command line parameters separated by a space - the org aliases to update

if [ "$#" -eq 0 ]; then
    echo "You must enter at least one org alias - or several separated by a space"
    exit 1
fi
echo "Start 2-devsandboxconfig EmailAddressInvalid"

echo "Orgs to be updated: $@"

for var in "$@"
do
    ORGALIAS="$var"
    echo "Updating org: $ORGALIAS"

# TODO: add step to change validation rule in data to true and activate it again after prodly 

    ### 5 - UPDATE EMAIL ADDRESSES INVALID
    sfdx force:apex:execute -f ../apex/EmailAddressInvalid.cls -u $ORGALIAS
    # we don't have Contacts, Leads, Alt until after Prodly

done
echo "Finished 2-devsandboxconfig EmailAddressInvalid"
