#!/bin/bash
# Sandbox configuration script for Developer Sandboxes
# This script is run after the second Prodly deployment and CPQ configuration
# Script takes command line parameters separated by a space - the org aliases to update

if [ "$#" -eq 0 ]; then
    echo "You must enter at least one org alias - or several separated by a space"
    exit 1
fi
echo "Start 3-devsandboxconfig DeleteCustomActionDuplicates, DeleteLineColumnExtras"

echo "Orgs to be updated: $@"

for var in "$@"
do
    ORGALIAS="$var"
    echo "Updating org: $ORGALIAS"

    ### 6 - DELETE DUPLICATE CUSTOMACTION LINECOLUMN
    sfdx force:apex:execute -f ../apex/DeleteCustomActionDuplicates.cls -u $ORGALIAS
    sfdx force:apex:execute -f ../apex/DeleteLineColumnExtras.cls -u $ORGALIAS
done
echo "Finished 3-devsandboxconfig DeleteCustomActionDuplicates, DeleteLineColumnExtras"
