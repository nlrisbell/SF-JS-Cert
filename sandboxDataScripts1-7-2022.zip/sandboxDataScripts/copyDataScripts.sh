#!/bin/bash
# Sandbox configuration script for Developer Sandboxes
# This script is run first to place the /data and /scripts files and directories in the project

echo "Start copyDataScripts"
cp -r data ../data
cp scripts/apex/* ../scripts/apex
cp -r scripts/sandboxconfig ../scripts
echo "Finished copyDataScripts"
